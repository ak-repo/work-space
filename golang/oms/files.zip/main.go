package main

import (
	"fmt"
	"log"
	"net/http"

	"order-delivery/handlers"
	"order-delivery/services"
	"order-delivery/store"
)

func main() {
	// Wire up the dependency chain: store → service → handler
	s := store.New()
	svc := services.New(s)
	h := handlers.New(svc)

	mux := http.NewServeMux()
	handlers.RegisterRoutes(mux, h)

	addr := ":8080"
	fmt.Println("Order & Delivery service running on http://localhost" + addr)
	fmt.Println()
	fmt.Println("  POST   /orders")
	fmt.Println("  GET    /orders/{id}")
	fmt.Println("  PUT    /orders/{id}/status")

	if err := http.ListenAndServe(addr, mux); err != nil {
		log.Fatalf("server error: %v", err)
	}
}
